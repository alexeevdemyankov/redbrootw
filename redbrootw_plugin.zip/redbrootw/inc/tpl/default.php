<?php
include "header.php";
?>
<div class="rbo__main">
    <div class="rbo__form">
        <H1>FREE OPENCART TO WOOCOMMERCE EXPORT</H1>
        <a href="https://boosty.to/alexeevdemyankov/" target="_blank" style="font-size: larger; color: red;">Donate me boosty.to (Alexeev-Demyankov Ilya)</a>
        <p>
            Free plugin for Export product data
        </p>
        <p>
            FULL FREE WORKING! <br>
            - import products base params <br>
            - import category <br>
            - import attributes <br>
            - import variable products (create variations by params) <br>
            - import images <br>
            - import galery <br>
            - import base price  <br>
            - convert stock vars <br>
        </p>
        <p>
            In process <br>
            - import SEO <br>
            - import Quanity <br>
            - import Sale price <br>
        </p>

        <p>
            Coming soon <br>
            - import category images <br>
            - logger errors <br>
        </p>



    </div>
</div>